<?php

namespace Controllers;

use Model\Platillo;
use MVC\Router;

class APIPlatillos
{

    public static function index()
    {
    }
}
