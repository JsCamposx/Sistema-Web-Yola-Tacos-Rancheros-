
<div class="dashboard__topbar">
    <div class="dashboard__toggle">
        <i class="fa-solid fa-bars"></i>
    </div>

    <div class="dashboard__user">
        <img src="/img/dashboard/user.jpeg" alt="Imagen Usuario" loading="lazy">
    </div>
 </div>   
